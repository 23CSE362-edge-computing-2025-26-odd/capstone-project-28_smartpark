import heapq
import time


class Task:
    def __init__(self, name, deadline, action):
        self.name = name
        self.deadline = deadline   
        self.action = action

    def __lt__(self, other):
        return self.deadline < other.deadline


# EDF Scheduler
class EDFScheduler:
    def __init__(self):
        self.task_queue = []

    def add_task(self, task):
        heapq.heappush(self.task_queue, task)

    def run(self):
        while self.task_queue:
            task = heapq.heappop(self.task_queue)
            print(f"[EDF] Running task: {task.name} (Deadline: {task.deadline}ms)")
            print(f"Action: {task.action}") 
            time.sleep(0.5)


if __name__ == "__main__":
    scheduler = EDFScheduler()

    scheduler.add_task(Task("Collision Alert", 2, "Brake / Avoid obstacle"))
    scheduler.add_task(Task("Rerouting", 10, "Find alternative route"))
    scheduler.add_task(Task("Routine Update", 20, "Send GPS data to cloud"))

    scheduler.run()
