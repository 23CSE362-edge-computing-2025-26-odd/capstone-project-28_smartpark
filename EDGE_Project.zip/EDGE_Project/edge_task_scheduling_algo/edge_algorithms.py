import heapq
import time
import random


class Task:
    def __init__(self, name, deadline, action):
        self.name = name
        self.deadline = deadline   
        self.action = action

    def __lt__(self, other):
        return self.deadline < other.deadline


# EDF Scheduler

class EDFScheduler:
    def __init__(self):
        self.task_queue = []

    def add_task(self, task):
        heapq.heappush(self.task_queue, task)

    def get_next_task(self):
        if self.task_queue:
            return heapq.heappop(self.task_queue)
        return None



# Resource Availability Checks
def edge_available():
    overloaded = random.choice([True, False])
    if overloaded:
        print("Edge is OVERLOADED or FAILED")
        return False
    return True

def fog_available():
  
    return random.choice([True, True, True, False, False])


# Task Execution

def execute_task(task, location):
    print(f"[FTTO] Executing '{task.name}' at {location}")
    print(f"-> Action: {task.action}")
    time.sleep(0.5)

def offload_task(task):
    if edge_available():
        execute_task(task, "EDGE ")
    elif fog_available():
        execute_task(task, "FOG ")
    else:
        execute_task(task, "CLOUD ")


if __name__ == "__main__":
    scheduler = EDFScheduler()


    scheduler.add_task(Task("Collision Alert", 2, "Brake / Avoid obstacle"))
    scheduler.add_task(Task("Rerouting", 10, "Find alternative route"))
    scheduler.add_task(Task("Routine Update", 20, "Send GPS data to cloud"))

    print("=== EDF + FTTO Simulation Started ===\n")
     
    while True:
        task = scheduler.get_next_task()
        if not task:
            break  
        print(f"[EDF] Picked Task: {task.name} (Deadline: {task.deadline}ms)")
        offload_task(task)
        print("\n")

    print("Simulation Finished ")
