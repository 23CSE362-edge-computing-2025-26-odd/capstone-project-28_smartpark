import random
import time

def edge_available():
    return random.choice([True, False])   

def fog_available():
    return random.choice([True, False])

def execute_task(task, location):
    print(f"[FTTO] Executing {task} at {location}")
    time.sleep(0.5)



def offload_task(task):
    if edge_available():
        execute_task(task, "EDGE ")
    elif fog_available():
        execute_task(task, "FOG layer ")
    else:
        execute_task(task, "CLOUD ")


if __name__ == "__main__":
    tasks = ["Collision Alert", "Rerouting", "Routine Update"]

    for i in tasks:
        print(f"\nProcessing Task: {i}")
        offload_task(i)
